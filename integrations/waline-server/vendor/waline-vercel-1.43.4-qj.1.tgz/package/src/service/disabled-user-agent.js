// Quiet Journal profile, added 2026-10-16. Upstream license: see LICENSE.
// Explicit disabled-feature adapter, not a parser fallback.
module.exports = function disabledUserAgent() {
  if (process.env.DISABLE_USERAGENT !== 'true') throw new Error('User-Agent parsing is not available in this profile.');
  return { browser: {}, cpu: {}, device: {}, engine: {}, os: {} };
};
