// Quiet Journal profile, modified 2026-10-16. Upstream license: see LICENSE.
// This deployment uses moderation, never third-party spam submission.
module.exports = class extends think.Service {
  constructor(blog) {
    super(blog);
    if (process.env.AKISMET_KEY !== 'false') throw new Error('This profile does not include Akismet.');
  }
  async check() { return false; }
};
