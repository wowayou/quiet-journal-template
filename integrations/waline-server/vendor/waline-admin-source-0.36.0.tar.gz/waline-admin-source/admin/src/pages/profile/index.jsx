import cls from 'classnames';
import React, { useState } from 'react';
import { Trans, useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../../components/Header.jsx';
// oxlint-disable-next-line import/no-namespace
import * as Icons from '../../components/icon';
import { updateProfile } from '../../services/user.js';
import { buildAvatar } from '../manage-comments/utils.js';
import TwoFactorAuth from './twoFactorAuth.jsx';

const unbind = async (type) => {
  await updateProfile({ [type]: '' });
  location.reload();
};

export default function Profile() {
  // oxlint-disable-next-line react/hook-use-state
  const [isPasswordUpdating, setPasswordUpdating] = useState(false);
  // oxlint-disable-next-line react/hook-use-state
  const [isProfileUpdating, setProfileUpdating] = useState(false);
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);
  const { t } = useTranslation();

  const onProfileUpdate = async (event) => {
    event.preventDefault();

    const display_name = event.target.screenName.value;
    const url = event.target.url.value;
    const label = event.target.label.value;
    const email = event.target.email.value;

    if (!display_name || !url) {
      alert(t('nickname and homepage are required'));

      return;
    }

    setProfileUpdating(true);
    try {
      await dispatch.user.updateProfile({ display_name, url, label, email });
    } catch (err) {
      alert(err);
    } finally {
      setProfileUpdating(false);
    }
  };

  const onPasswordUpdate = async (event) => {
    event.preventDefault();

    const password = event.target.password.value;
    const confirm = event.target.confirm.value;

    if (!password || !confirm) {
      alert(t('please input password'));

      return;
    }

    if (password !== confirm) {
      alert(t("passwords don't match"));

      return;
    }

    setPasswordUpdating(true);
    await updateProfile({ password });
    setPasswordUpdating(false);
  };

  const changeAvatar = async (event) => {
    event.preventDefault();

    const url = prompt(t('please input avatar url'));

    if (!url) {
      return;
    }

    await updateProfile({ avatar: url });
    location.reload();
  };

  const baseUrl = window.serverURL || (location.pathname.match(/(.*?\/)ui/u)?.[1] ?? '/');

  const qs = new URLSearchParams(location.search);
  const token =
    window.TOKEN ??
    sessionStorage.getItem('TOKEN') ??
    qs.get('token') ??
    localStorage.getItem('TOKEN');

  const socials = Array.isArray(window.oauthServices)
    ? window.oauthServices.map(({ name }) => name)
    : ['oidc', 'qq', 'weibo', 'github', 'twitter', 'facebook'];

  return (
    <>
      <Header />
      <div className="main">
        <div className="body container">
          <div className="typecho-page-title">
            <h2>{t('setting')}</h2>
          </div>
          <div className="row typecho-page-main">
            <div className="col-mb-12 col-tb-3">
              <p>
                <button
                  type="button"
                  className="profile-avatar-btn"
                  title={t('change avatar')}
                  onClick={changeAvatar}
                >
                  <img
                    className="profile-avatar"
                    src={buildAvatar(user.email, user.avatar)}
                    alt={t('avatar')}
                  />
                </button>
              </p>
              <h2>{user.display_name}</h2>
              <p>{user.email}</p>
            </div>

            <div className="col-mb-12 col-tb-6 col-tb-offset-1 typecho-content-panel">
              <section>
                <h3>{t('profile')}</h3>
                <form method="post" onSubmit={onProfileUpdate}>
                  <ul className="typecho-option">
                    <li>
                      <label className="typecho-label" htmlFor="screenName-0-1">
                        {t('nickname')}
                      </label>
                      <input
                        id="screenName-0-1"
                        name="screenName"
                        type="text"
                        className="text"
                        defaultValue={user.display_name}
                      />
                      <p className="description" />
                    </li>
                  </ul>

                  <ul className="typecho-option">
                    <li>
                      <label className="typecho-label" htmlFor="email-0-2">
                        {t('email')}
                      </label>
                      <input
                        id="email-0-2"
                        name="email"
                        type="text"
                        className="text"
                        defaultValue={user.email}
                      />
                      <p className="description" />
                    </li>
                  </ul>

                  <ul className="typecho-option">
                    <li>
                      <label className="typecho-label" htmlFor="url-0-3">
                        {t('homepage')}
                      </label>
                      <input
                        id="url-0-3"
                        name="url"
                        type="text"
                        className="text"
                        defaultValue={user.url}
                      />
                      <p className="description">
                        <Trans
                          i18nKey="homepage tips"
                          defaults="Current users' homepage. It must be start with <code>http://</code> or <code>https://</code>."
                          components={{ code: <code /> }}
                        />
                      </p>
                    </li>
                  </ul>

                  <ul className="typecho-option">
                    <li>
                      <label className="typecho-label" htmlFor="url-0-2">
                        {t('exclusive label')}
                      </label>
                      <input
                        id="url-0-2"
                        name="label"
                        type="text"
                        className="text"
                        defaultValue={user.label}
                      />
                      <p className="description" />
                    </li>
                  </ul>

                  <ul className="typecho-option typecho-option-submit">
                    <li>
                      <button type="submit" className="btn primary" disabled={isProfileUpdating}>
                        {t('update my profile')}
                      </button>
                    </li>
                  </ul>
                </form>
              </section>
              <br />
              <section id="social-account">
                <h3>{t('connect to social account')}</h3>
                <div className="account-list">
                  {socials.map((social) => {
                    // oxlint-disable-next-line import/namespace
                    const Icon = Icons[social];

                    return (
                      <div
                        key={social}
                        className={cls('account-item', social, {
                          bind: user[social],
                        })}
                      >
                        <a
                          href={
                            user[social]
                              ? social === 'oidc'
                                ? ''
                                : `https://${social}.com/${user[social]}`
                              : `${baseUrl}oauth?type=${social}&state=${token}`
                          }
                          target={user[social] ? '_blank' : '_self'}
                          rel="noreferrer"
                        >
                          {Icon ? <Icon className="social-icon" aria-hidden="true" /> : null}
                        </a>
                        <button
                          type="button"
                          className="account-unbind"
                          aria-label={t('unbind')}
                          onClick={() => unbind(social)}
                        >
                          <svg
                            className="close-icon"
                            viewBox="0 0 1024 1024"
                            xmlns="http://www.w3.org/2000/svg"
                            width="14"
                            height="14"
                          >
                            <path d="m568.569 512 170.267-170.267c15.556-15.556 15.556-41.012 0-56.569s-41.012-15.556-56.569 0L512 455.431 341.733 285.165c-15.556-15.556-41.012-15.556-56.569 0s-15.556 41.012 0 56.569L455.431 512 285.165 682.267c-15.556 15.556-15.556 41.012 0 56.569 15.556 15.556 41.012 15.556 56.569 0L512 568.569l170.267 170.267c15.556 15.556 41.012 15.556 56.569 0 15.556-15.556 15.556-41.012 0-56.569L568.569 512z" />
                          </svg>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </section>
              <br />
              <section id="change-password">
                <h3>{t('change password')}</h3>
                <form method="post" onSubmit={onPasswordUpdate}>
                  <ul className="typecho-option">
                    <li>
                      <label className="typecho-label" htmlFor="password-0-11">
                        {t('password')}
                      </label>
                      <input
                        id="password-0-11"
                        name="password"
                        type="password"
                        className="w-60"
                        autoComplete="new-password"
                      />
                      <p className="description">
                        <Trans i18nKey="password tips" />
                      </p>
                    </li>
                  </ul>

                  <ul className="typecho-option">
                    <li>
                      <label className="typecho-label" htmlFor="confirm-0-12">
                        {t('password again')}
                      </label>
                      <input
                        id="confirm-0-12"
                        name="confirm"
                        type="password"
                        className="w-60"
                        autoComplete="new-password"
                      />
                      <p className="description">
                        <Trans i18nKey="password again tips" />
                      </p>
                    </li>
                  </ul>
                  <ul className="typecho-option typecho-option-submit">
                    <li>
                      <button type="submit" className="btn primary" disabled={isPasswordUpdating}>
                        {t('update password')}
                      </button>
                    </li>
                  </ul>
                </form>
              </section>
              <br />
              <TwoFactorAuth />
              <br />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
