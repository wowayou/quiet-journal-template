import React, { useEffect, useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router';

import Header from '../../components/Header.jsx';
// oxlint-disable-next-line import/no-namespace
import * as Icons from '../../components/icon';
import { useCaptcha } from '../../components/useCaptcha.js';
import { get2FAToken } from '../../services/user.js';

export default function Login() {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector((state) => state.user);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  // oxlint-disable-next-line react/hook-use-state
  const [is2FAEnabled, enable2FA] = useState(false);
  const execute = useCaptcha({
    sitekey: window.turnstileKey ?? window.recaptchaV3Key,
    hideDefaultBadge: true,
  });

  const basePath = location.pathname.match(/(.*?\/)ui/u)?.[1] ?? '/';
  const query = useMemo(() => new URLSearchParams(location.search), []);

  useEffect(() => {
    if (!user || !user.objectId) {
      return;
    }

    const isAdmin = user.type === 'administrator';

    const defaultRedirect = isAdmin ? '/ui' : '/ui/profile';
    const redirect = isAdmin && query.get('redirect') ? query.get('redirect') : defaultRedirect;

    const normalizedRedirect = redirect.replaceAll(/(^|[^:])\/{2,}/gu, '$1/');

    if (/^https?:\/\//iu.test(normalizedRedirect)) {
      try {
        const redirectURL = new URL(normalizedRedirect);
        const referrerHost = document.referrer ? new URL(document.referrer).host : '';

        if (referrerHost && redirectURL.host === referrerHost) {
          const token =
            localStorage.getItem('TOKEN') ?? sessionStorage.getItem('TOKEN') ?? window.TOKEN;

          if (token) {
            redirectURL.searchParams.set('token', token);
          }

          location.href = redirectURL.href;
          return;
        }
      } catch {
        // Ignore malformed redirect/referrer values and fall back to default.
      }
    }

    navigate(defaultRedirect);
  }, [user, query, navigate]);

  const onSubmit = async (event) => {
    event.preventDefault();
    setError(false);
    setLoading(true);

    const email = event.target.email.value;
    const password = event.target.password.value;
    const code = event.target.code ? event.target.code.value : '';
    const remember = event.target.remember.checked;

    if (!email) {
      return setError(t('please input email'));
    }

    if (!password) {
      return setError(t('please input password'));
    }

    if (event.target.code && !code) {
      return setError(t('please input 2fa code'));
    }

    const token = await execute('login');

    try {
      await dispatch.user.login({
        email,
        password,
        code,
        remember,
        recaptchaV3: window.recaptchaV3Key ? token : undefined,
        turnstile: window.turnstileKey ? token : undefined,
      });
    } catch {
      setError(t('email or password error'));
    } finally {
      setLoading(false);
    }
  };

  const check2FACode = async (event) => {
    const email = event.target.value;

    if (!email) {
      return;
    }

    const data = await get2FAToken(email);

    enable2FA(data.enable);
  };

  const baseUrl = window.serverURL || (location.pathname.match(/(.*?\/)ui/u)?.[1] ?? '/');

  const socials = Array.isArray(window.oauthServices)
    ? window.oauthServices.map(({ name }) => name)
    : ['oidc', 'qq', 'weibo', 'github', 'twitter', 'facebook'];

  const buildOAuthURL = (social) => {
    const redirect = query.get('redirect') || `${basePath}ui/profile`;
    return `${baseUrl}oauth?type=${encodeURIComponent(social)}&redirect=${encodeURIComponent(redirect)}`;
  };

  return (
    <>
      <Header />
      <div
        className="message popup notice"
        style={{
          position: 'fixed',
          top: 0,
          display: error ? 'block' : 'none',
        }}
      >
        <ul>{error ? <li>{error}</li> : null}</ul>
      </div>
      <div className="typecho-login-wrap">
        <div className="typecho-login">
          {/* <h1><a href="http://waline.js.org" className="i-logo">Waline</a></h1> */}

          <form method="post" name="login" onSubmit={onSubmit}>
            <p>
              <label htmlFor="email" className="sr-only">
                {t('email')}
              </label>
              <input
                type="text"
                id="email"
                name="email"
                placeholder={t('email')}
                className="text-l w-100"
                onBlur={check2FACode}
              />
            </p>
            <p>
              <label htmlFor="password" className="sr-only">
                {t('password')}
              </label>
              <input
                type="password"
                id="password"
                name="password"
                className="text-l w-100"
                placeholder={t('password')}
              />
            </p>
            {is2FAEnabled && (
              <p>
                <label htmlFor="code" className="sr-only">
                  {t('2fa code')}
                </label>
                <input
                  type="text"
                  id="code"
                  name="code"
                  className="text-l w-100"
                  placeholder={t('2fa code')}
                />
              </p>
            )}
            <p className="captcha-container" />
            <p className="submit">
              <button type="submit" className="btn btn-l w-100 primary" disabled={loading}>
                {t('login')}
              </button>
            </p>
            <p style={{ display: 'flex', justifyContent: 'space-between' }}>
              <label htmlFor="remember">
                <input type="checkbox" name="remember" className="checkbox" id="remember" />{' '}
                {t('remember me')}
              </label>
              <span className="right forgot-password">
                <Link to="/ui/forgot">{t('forgot password')}</Link>
              </span>
            </p>
          </form>
          <div className="social-accounts">
            {socials.map((social) => {
              // oxlint-disable-next-line import/namespace
              const Icon = Icons[social];

              return (
                <a key={social} href={buildOAuthURL(social)}>
                  {Icon ? <Icon className="social-icon" aria-hidden="true" /> : null}
                </a>
              );
            })}
          </div>

          <p className="more-link">
            <Link to="/ui">{t('back to home')}</Link>
            {' • '}
            <Link to="/ui/register">{t('register')}</Link>
          </p>
        </div>
      </div>
    </>
  );
}
