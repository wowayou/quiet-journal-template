Waline admin 0.36.0 application source: c0a8f7c0ecf6dc24fab02845b1195753bdec0997. GPL-2.0; see admin/LICENSE and upstream-build/README.md.
This is a disclosed rebuild, not the unmodified npm admin.js. Application source was not edited.
Build changes: isolated npm manifest/lock, @vitejs/plugin-react 6.1.2, hidden source map.
From admin/: npm ci --ignore-scripts --no-audit --no-fund; npm run build (Node 24).
Expected dist/admin.js SHA-256: 1ec61f7b6bad65cb52ad803914754b54f967c382680d0c0083e39fd6811718c6
No GitHub Actions, cloud account, release command or runtime source-map URL is needed.
third-party/ preserves the published source and license files of every bundled npm module.
The hidden map additionally contains the exact sources of all modules used in this output.
