Waline server 1.43.4, Quiet Journal profile. GPL-2.0; see server/LICENSE.
The server/ directory is the exact patched npm package source, including its bundled core output.
Preferred TypeScript core sources and original build inputs are from c4b0f1ebb9a7970d36493d4c3580f3f43e098fa5.
QJ-PROFILE.json lists every change; controllers, authentication, moderation and SQL storage are not rewritten.
prepare-vendor.py reproduces the profile from separately obtained, hash-pinned upstream inputs.
Runtime dependencies retain their own licenses. This is not a redistributable all-dependency server image.
